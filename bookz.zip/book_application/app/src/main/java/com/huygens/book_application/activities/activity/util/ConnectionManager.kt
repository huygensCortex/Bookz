package com.huygens.book_application.activities.activity.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo

class ConnectionManager {


    fun checkConnectivity(context: Context):Boolean{
        // network of device what?

        // info about currently active network
        val connectivityManager = context
            .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        //check for active network
        val activeNetwork : NetworkInfo? = connectivityManager.activeNetworkInfo

        return if (activeNetwork?.isConnected!=null) {
            activeNetwork.isConnected
        } else{
            false
        }


    }

}