package com.huygens.book_application.activities.activity.model

data class Book (
    
    val bookId: String,
    val bookName : String,
    val bookAuthor : String,
    val bookRating : String,
    val bookCost : String,
    val bookImage :String
)