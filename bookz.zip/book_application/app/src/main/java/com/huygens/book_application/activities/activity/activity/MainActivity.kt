package com.huygens.book_application.activities.activity.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.huygens.book_application.activities.activity.fragment.DashboardFragment
import com.huygens.book_application.activities.activity.fragment.Favoraites
import com.huygens.book_application.R

class MainActivity : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var toolbar: androidx.appcompat.widget.Toolbar
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var frameLayout: FrameLayout
    lateinit var navigationView: NavigationView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout=findViewById(R.id.drawer)
        toolbar=findViewById(R.id.toolbar)
        coordinatorLayout=findViewById(R.id.coordinator)
        frameLayout=findViewById(R.id.framelayout)
        navigationView=findViewById(R.id.nav_draw)


        var prevmenitm: MenuItem? =null


        setUpToolbar()

        //for opening dashboard screen when app is opened
        openDashboard()

        val actionBarDrawerToggle = ActionBarDrawerToggle(
            this@MainActivity,drawerLayout,
            R.string.open_drawer,
            R.string.close_drawer
        )

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState() //change hamb icon to back aroow icon


        navigationView.setNavigationItemSelectedListener setNavigationItemSelectedlistener@{

            // for checking /highligiting clicked menu items
            if (prevmenitm != null){
                prevmenitm?.isChecked=false

            }
            it.isCheckable =true
            it.isChecked=true
            prevmenitm=it


            when(it.itemId) //it for currently clicked
            {
                R.id.itm_dash -> {
                    supportFragmentManager.beginTransaction()
                        .replace(
                            R.id.framelayout,
                            DashboardFragment()
                        )
                       // .addToBackStack("Dashboard")
                        .commit()
                    //close drawer
                    supportActionBar?.title="Dashboard" //for displaying dashboard name on tool bar
                    drawerLayout.closeDrawers()


                }

                R.id.itm_fav -> {

                    //Toast.makeText(this@MainActivity,"Favorites clicked",Toast.LENGTH_SHORT).show()
                    supportFragmentManager.beginTransaction()
                        .replace(
                            R.id.framelayout,
                            Favoraites()
                        )
                        //.addToBackStack("Favorites")
                        .commit()
                    supportActionBar?.title="Fav"
                    drawerLayout.closeDrawers()

                }


            }




            return@setNavigationItemSelectedlistener true

        }










    }


    fun setUpToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title="Bookz"
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

    }
//click listener for action bar
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id==android.R.id.home){
            drawerLayout.openDrawer(GravityCompat.START) //to open from left side
        }
        return super.onOptionsItemSelected(item)


    }
    fun openDashboard()
    {
        supportFragmentManager.beginTransaction()
            .replace(
                R.id.framelayout,
                DashboardFragment()
            )
            .addToBackStack("Dashboard")
            .commit()
        supportActionBar?.title="Dashboard"

        // for checking dashboard

        navigationView.setCheckedItem(R.id.itm_dash)
    }

    override fun onBackPressed() {
        val frag = supportFragmentManager.findFragmentById(R.id.framelayout)

        when (frag) {
            !is DashboardFragment -> openDashboard()

            else -> super.onBackPressed()
        }
    }




}
