package com.huygens.book_application.activities.activity.fragment

import com.huygens.book_application.activities.activity.adapter.FavouriteRecyclerAdapter
import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.huygens.book_application.R
import com.huygens.book_application.activities.activity.database.BookDatabase
import com.huygens.book_application.activities.activity.database.BookEntities

/**
 * A simple [Fragment] subclass.
 */
class Favoraites : Fragment() {

    lateinit var recyclerFavourites: RecyclerView
    lateinit var progressLayout: RelativeLayout
    lateinit var progressBar : ProgressBar
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: FavouriteRecyclerAdapter
    var dbBookList =listOf<BookEntities>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this com.huygens.book_application.activities.com.huygens.book_application.activities.activity.activity.fragment
        val view= inflater.inflate(R.layout.fragment_favoraites, container, false)

        recyclerFavourites=view.findViewById(R.id.recyclerViewFav)
        progressBar=view.findViewById(R.id.progressBar)
        progressLayout=view.findViewById(R.id.progressLayout)

        layoutManager = GridLayoutManager(activity as Context,2)

        dbBookList=RetrieveFavourites(activity as Context).execute().get()

        if (activity != null){
            progressLayout.visibility=View.GONE
            recyclerAdapter = FavouriteRecyclerAdapter(activity as Context, dbBookList)
            recyclerFavourites.adapter=recyclerAdapter
            recyclerFavourites.layoutManager=layoutManager
        }









        return view
    }

    class RetrieveFavourites(val context: Context):AsyncTask<Void,Void,List<BookEntities>>(){
        override fun doInBackground(vararg params: Void?): List<BookEntities> {
            val db = Room.databaseBuilder(context,BookDatabase::class.java,"book-db").build()
            return db.bookDao().getAllBooks()
        }

    }

}
