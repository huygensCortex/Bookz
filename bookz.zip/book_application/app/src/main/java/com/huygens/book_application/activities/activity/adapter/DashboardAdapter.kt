package com.huygens.book_application.activities.activity.adapter

import com.huygens.book_application.activities.activity.activity.DescriptionActivity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.huygens.book_application.R
import com.squareup.picasso.Picasso
import com.huygens.book_application.activities.activity.model.Book
import java.util.ArrayList


class DashboardRecyclerAdapter(val context: Context,val itmList : ArrayList<Book>) : RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>(){ //links both classes

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_item_single_row,parent,false)
        return DashboardViewHolder(view)

    }
    override fun getItemCount(): Int {
        return itmList.size
    }
    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
      // below code for the first case where only name of books from array list was displayed
       /* val text = itmList[position]
        holder.textView.text=text */

        val book = itmList[position]
        holder.textBookName.text=book.bookName
        holder.txtBookAuthor.text=book.bookAuthor
        holder.txtPrice.text=book.bookCost
        holder.txtRating.text=book.bookRating
       // holder.imgBook.setImageResource(book.bookImage)
        Picasso.get().load(book.bookImage).error(R.drawable.default_book_cover).into(holder.imgBook)

        //adding click listener
        //fun LinearLayout.setOnClickListener()
        holder.l1Content.setOnClickListener(){
            val intent = Intent(context,
                DescriptionActivity::class.java)
            intent.putExtra("book_id",book.bookId)
            context.startActivity(intent)


        }



    }

    class DashboardViewHolder(view:View): RecyclerView.ViewHolder(view){
        val textBookName : TextView = view.findViewById(R.id.txtBookName)
        val txtBookAuthor : TextView =view.findViewById(R.id.txtBookAuthor)
        val txtPrice :  TextView =view.findViewById(R.id.txtBookPrice)
        val txtRating : TextView=view.findViewById(R.id.txtBookRating)
        val imgBook : ImageView=view.findViewById(R.id.imgBookImage)
        val l1Content : LinearLayout= view.findViewById(R.id.l1Content)


    }

}



