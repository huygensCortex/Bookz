package com.huygens.book_application.activities.activity.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.huygens.book_application.R
import com.squareup.picasso.Picasso
import com.huygens.book_application.activities.activity.database.BookDatabase
import com.huygens.book_application.activities.activity.database.BookEntities
import org.json.JSONObject
import com.huygens.book_application.activities.activity.util.ConnectionManager

class DescriptionActivity : AppCompatActivity() {

    lateinit var bookName: TextView
    lateinit var bookAuthor: TextView
    lateinit var bookPrice: TextView
    lateinit var bookRating: TextView
    lateinit var bookImg: ImageView
    lateinit var bookDes: TextView
    lateinit var btnAddFav : Button
   lateinit var progressBar: ProgressBar
   lateinit var progressLayout: RelativeLayout

    var bookId: String?= "100"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
        bookName= findViewById(R.id.txtBookName)
        bookAuthor=findViewById(R.id.txtBookAuthor)
        bookPrice=findViewById(R.id.txtBookPrice)
        bookRating=findViewById(R.id.txtBookRating)
        bookImg=findViewById(R.id.imgBook)
        bookDes=findViewById(R.id.txtDes)
        btnAddFav=findViewById(R.id.btnFav)
        progressBar=findViewById(R.id.progressBar)
        progressBar.visibility=View.VISIBLE
        progressLayout=findViewById(R.id.relProgress)
        progressLayout.visibility=View.VISIBLE

        if(intent != null){
            bookId= intent.getStringExtra("book_id")

        }else
        {
            finish()
            Toast.makeText(this@DescriptionActivity,
                "Some unexpected error occurred",Toast.LENGTH_SHORT).show()

        }
        if (bookId=="100")
        {
            Toast.makeText(this@DescriptionActivity,
                "Some unexpected error occurred",Toast.LENGTH_SHORT).show()
        }

        val queue =Volley.newRequestQueue(this@DescriptionActivity)
        val url ="http://13.235.250.119/v1/book/get_book/"
        if(ConnectionManager().checkConnectivity(this@DescriptionActivity as Context)) {
            val jsonParams = JSONObject()
            jsonParams.put("book_id", bookId)
            val jsonRequest =
                object : JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {

                    try {
                        val success = it.getBoolean("success")
                        if (success) {
                            val bookJsonObject = it.getJSONObject("book_data")
                            progressLayout.visibility = View.GONE

                            //to store book img
                            val bookImageUrl = bookJsonObject.getString("image")

                            Picasso.get().load(bookJsonObject.getString("image")).into(bookImg)
                            bookName.text = bookJsonObject.getString("name")
                            bookAuthor.text = bookJsonObject.getString("author")
                            bookPrice.text = bookJsonObject.getString("price")
                            bookRating.text = bookJsonObject.getString("rating")
                            bookDes.text = bookJsonObject.getString("description")

                            val bookEntities = BookEntities(
                                bookId?.toInt() as Int,
                                bookName.text.toString(),
                                bookAuthor.text.toString(),
                                bookPrice.text.toString(),
                                bookRating.text.toString(),
                                bookDes.text.toString(),
                                bookImageUrl

                            )

                            // var to check for fav
                            val checkFav = DBAsyncTask(
                                applicationContext,
                                bookEntities,
                                1
                            ).execute()
                            val isFav = checkFav.get() // if a book is in fav or not

                            if (isFav){
                                btnAddFav.text= "Remove from Favorites"
                                val favColor =ContextCompat.getColor(applicationContext,R.color.colorFav)
                                btnAddFav.setBackgroundColor(favColor)

                            }else{
                                btnAddFav.text= "Add to Favorites"
                                val notFavColor =ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                btnAddFav.setBackgroundColor(notFavColor)
                            }
                              btnAddFav.setOnClickListener {

                                  if(!DBAsyncTask(
                                          applicationContext,
                                          bookEntities,
                                          1
                                      )
                                          .execute().get()){ //when book not a fav
                                      val async = DBAsyncTask(
                                          applicationContext,
                                          bookEntities,
                                          2
                                      ).execute()
                                      val result =async.get()
                                      if (result){
                                                Toast.makeText(
                                                    this@DescriptionActivity,
                                                    "Book added to Favorites",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                          btnAddFav.text="Remove from favorites"
                                          val favColor=ContextCompat.getColor(applicationContext,R.color.colorFav)
                                          btnAddFav.setBackgroundColor(favColor)
                                      } else{
                                          Toast.makeText(
                                              this@DescriptionActivity,
                                              "Some error occurred",
                                              Toast.LENGTH_SHORT
                                          ).show()
                                      }
                                  }else{
                                      // if book was already added to favorites
                                      val async = DBAsyncTask(
                                          applicationContext, bookEntities
                                          , 3
                                      ).execute()
                                      val result = async.get()
                                      if(result){
                                          Toast.makeText(
                                              this@DescriptionActivity,
                                              "Book removed from Favorites",
                                              Toast.LENGTH_SHORT
                                          ).show()
                                          btnAddFav.text= "Add to Favorites"
                                          val notFavColor =ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                          btnAddFav.setBackgroundColor(notFavColor)

                                      }else{
                                          Toast.makeText(
                                              this@DescriptionActivity,
                                              "Some error occurred",
                                              Toast.LENGTH_SHORT
                                          ).show()
                                      }
                                  }

                              }


                        } else {
                            Toast.makeText(
                                this@DescriptionActivity, "Some Unexpected error occurred"
                                , Toast.LENGTH_SHORT
                            ).show()
                        }

                    } catch (e: Exception) {
                        Toast.makeText(
                            this@DescriptionActivity, "Some Unexpected error occurred"
                            , Toast.LENGTH_SHORT
                        ).show()

                    }
                }

                    ,
                    Response.ErrorListener {
                        Toast.makeText(
                            this@DescriptionActivity, "Some Unexpected Volley error occurred"
                            , Toast.LENGTH_SHORT
                        ).show()
                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "4661dc0813afb2"
                        return headers
                    }

                }
            queue.add(jsonRequest)


        }else
        {
            val dialog=AlertDialog.Builder(this@DescriptionActivity as Context)
            dialog.setMessage("Internet connection not found")
            dialog.setTitle("error")
            dialog.setPositiveButton("Open Settings"){
                text, litener ->
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                this@DescriptionActivity.finish()


            }
            dialog.setNegativeButton("Exit"){
                text, listener->
                ActivityCompat.finishAffinity(this@DescriptionActivity as Activity)

            }
            dialog.create()
            dialog.show()




        }


    }

    class DBAsyncTask (val context : Context,val bookEntities: BookEntities,val mode: Int):
        AsyncTask<Void,Void,Boolean>(){

        /*
        Mode 1 -> Check DB if the book is favorite or not
        Mode 2 -> Save the book into DB as favorite
        Mode 3 -> Remove the favorite book
         */

        // initialize db globally
        val db = Room.databaseBuilder(context,BookDatabase::class.java,"book-db").build()


        override fun doInBackground(vararg params: Void?): Boolean {
            when(mode){
                1 -> {
                    //Check DB if the book is favorite or not
                    val book : BookEntities?= db.bookDao().getBookById(bookEntities.book_id.toString())
                    db.close()
                    return book != null // if return is null then false is returned
                }
                2 -> {
                   // Save the book into DB as favorite
                    db.bookDao().insertBook(bookEntities)
                    db.close()
                    return true
                }
                3 -> {
                   // Remove the favorite book
                    db.bookDao().deleteBook(bookEntities)
                    db.close()
                    return true
                }
            }

            return false
        }

    }
}









